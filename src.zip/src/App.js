import './App.css';
import {Auth} from "./components/Auth.js"

function App() {
  return (
    <div className="App">
     <Auth/>
    </div>
  );
}

export default App;
